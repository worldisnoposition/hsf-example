package com.aliware.edas;


public interface EchoService {
    String echo(String string);
}
